!function () {
    var e = /([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi, r = window.location.href, o = document.referrer;
    if (!e.test(r)) {
        var n = "//api.share.baidu.com/s.gif";
        o ? (n += "?r=" + encodeURIComponent(document.referrer), r && (n += "&l=" + r)) : r && (n += "?l=" + r);
        var t = new Image;
        t.src = n
    }
}(window);